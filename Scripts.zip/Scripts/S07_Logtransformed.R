## Log-transforming and adding PC column ###
knime.in$"Value" <- log10(knime.in$"Value")
knime.in$"PC"	<- paste("Log", knime.flow.in[["currentColumnName"]], sep = "")

knime.out <- knime.in