########### HFC info ##########
knime.out <- knime.in
knime.out$"Compound" <- strsplit(knime.flow.in[["Exposure scenario"]], ",")[[1]][1]