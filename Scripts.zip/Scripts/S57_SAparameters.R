####### Parameters needed for PBTK #################


knime.out <- data.frame(
  "solvingmethod" 		= "lsoda",
  "Ventilation work" 		= knime.flow.in[["Ventilation work"]],
  "Ventilation rest"		= knime.flow.in[["Ventilation rest"]],
  "Molar volume"			= knime.flow.in[["Molecular weight"]],
  "Exposure level"		= knime.flow.in[["Average Exposure"]],
  "Body height" 			= knime.flow.in[["Body height"]],
  "Body weight"			= knime.flow.in[["Body weight"]],
  "CLi"				= knime.flow.in[["Clearance"]],
  "PCblood"				= knime.in$"PCblood",
  "PCfat"				= knime.in$"PCfat",
  "PClung"				= knime.in$"PClung",
  "PCmuscle"			= knime.in$"PCmuscle",
  "PCliver"				= knime.in$"PCliver",
  "PCvessel"			= knime.in$"PCvessel"
)

colnames(knime.out) <- c("solvingmethod", "Ventilation work", "Ventilation rest", "Molar volume", "Exposure level", "Body height", "Body weight", "CLi", "PCblood", "PCfat", "PClung", "PCmuscle", "PCliver", "PCvessel")
##################### replacing PC ##################################
current = knime.flow.in[["currentColumnName"]]
n = match(current, colnames(knime.out))

knime.out[,n] <- knime.flow.in[["PClist"]]