####### ADDING information to predictions #####

knime.out <- knime.in
knime.out$"Generation" 	<- knime.flow.in[["Generation"]]
knime.out$"PC"			<- knime.flow.in[["PC"]]
knime.out$"Combo"		<- unique(knime.in$"Combo")[1]
knime.out$"n_descriptors" <- unique(knime.in$"n_descriptors")[1]