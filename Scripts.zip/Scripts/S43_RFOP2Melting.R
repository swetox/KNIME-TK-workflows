########### melting and renaming ##############
library(reshape2)

knime.in$"No" <- seq(1,117,1)
knime.out <- knime.in
#### Renaming ########
colnames(knime.in)[(ncol(knime.in)-2):(ncol(knime.in)-1)] <- c("PClabel", "Data")

######## Joining ########
knime.out <- melt(knime.in, id.vars = c("PClabel", "Data", "Descriptor", "No"), measure.vars = c("R2Change", "RMSEChange"), variable.name = "Parameter", value.name = "Value") 

