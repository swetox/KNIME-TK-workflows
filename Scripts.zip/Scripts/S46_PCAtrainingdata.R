################################
dimensions = ncol(knime.in)

knime.in$"Compound" <- "Training Data"
knime.in$"Dimensions" <- dimensions

######### Going out ###########
knime.out <- knime.in[,c(1,2,ncol(knime.in)-1,ncol(knime.in))]