############## All combination of height, weight and ventilation ###############

height = c(knime.flow.in[["Body height"]], knime.flow.in[["Minimum height"]],knime.flow.in[["Maximum height"]])
weight = c(knime.flow.in[["Body weight"]], knime.flow.in[["Minimum weight"]],knime.flow.in[["Maximum weight"]])
venrest = c(knime.flow.in[["Ventilation rest"]], knime.flow.in[["Minimum ventilation rest"]],knime.flow.in[["Maximum ventilation rest"]])
venwork = c(knime.flow.in[["Ventilation work"]], knime.flow.in[["Minimum ventilation work"]],knime.flow.in[["Maximum ventilation work"]])

########## Going out ###########################################################
knime.out <- expand.grid(height, weight, venrest, venwork)
colnames(knime.out)<- c("Body height", "Body weight", "Ventilation rest", "Ventilation work")