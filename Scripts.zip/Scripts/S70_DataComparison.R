library(PK)
######### Comparison of PBPK and experimental data #########

######## Subsets #############
d_blood_ex <- subset(knime.in, knime.in$"Compartment" == "Blood")
d_air_ex 	<- subset(knime.in, knime.in$"Compartment" == "Exhaled air")

d_blood_pbtk <- subset(knime.in, knime.in$"Compartment" == "Cmixven")
d_air_pbtk 	<- subset(knime.in, knime.in$"Compartment" == "Cexh")

# NCA analysis
nca_blood_ex 		<- nca.complete(time = d_blood_ex$time,conc = d_blood_ex$Concentration)
nca_air_ex		<- nca.complete(time = d_air_ex$time, conc = d_air_ex$Concentration)
nca_blood_pbtk 	<- nca.complete(time =d_blood_pbtk$time, conc = d_blood_pbtk$Concentration)
nca_air_pbtk 		<- nca.complete(time = d_air_pbtk$time, conc = d_air_pbtk$Concentration)

# RMSE 
RMS_blood_ex 		= sqrt(mean(d_blood_ex$Concentration^2))
RMS_air_ex 		= sqrt(mean(d_air_ex$Concentration^2))

RMSE_blood		= sqrt(mean((d_blood_pbtk$Concentration-d_blood_ex$Concentration)^2))
RMSE_air			= sqrt(mean((d_air_pbtk$Concentration-d_air_ex$Concentration)^2))

# N timepoints
nblood 			= length(d_blood_ex$time)
nair 			= length(d_air_ex$time)

# Index 			
Index_blood		= RMSE_blood/RMS_blood_ex
Index_air			= RMSE_air/RMS_air_ex
Index_total 		= Index_blood*(nblood/(nblood+nair))+Index_air*(nair/(nblood+nair))

# Halflife
lm_blood_ex		= lm(log(Concentration) ~ time, subset(d_blood_ex, time>130 & time<400))
lm_air_ex			= lm(log(Concentration) ~ time, subset(d_air_ex, time>130 & time<400))
lm_blood_pbtk		= lm(log(Concentration) ~ time, subset(d_blood_pbtk, time>130 & time<400))
lm_air_pbtk		= lm(log(Concentration) ~ time, subset(d_air_pbtk, time>130 & time<400))

thalf_blood_ex		= log(2)/-summary(lm_blood_ex)$coefficients[2]
thalf_air_ex		= log(2)/-summary(lm_air_ex)$coefficients[2]
thalf_blood_pbtk	= log(2)/-summary(lm_blood_pbtk)$coefficients[2]
thalf_air_pbtk		= log(2)/-summary(lm_air_pbtk)$coefficients[2]

r2_blood_ex		= summary(lm_blood_ex)$r.squared
r2_air_ex			= summary(lm_air_ex)$r.squared
r2_blood_pbtk		= summary(lm_blood_pbtk)$r.squared
r2_air_pbtk		= summary(lm_air_pbtk)$r.squared

######### Dataframe  ########################################
dataframe 		<- data.frame("Scenario" = rep(knime.flow.in[["Scenario"]], 4))
dataframe$"Source"					<- knime.flow.in[["Source"]]
dataframe$"Compartment"				<- c("Blood", "Blood", "Exhaled air", "Exhaled air")
dataframe$"Data"					<- c("PBTK", "In vivo", "PBTK", "In vivo")

dataframe$"AUC"					<- c(nca_blood_pbtk$est[1],
                         nca_blood_ex$est[1],
                         nca_air_pbtk$est[1],
                         nca_air_ex$est[1])
dataframe$"AUCratio"				<- c(nca_blood_pbtk$est[1]/nca_blood_ex$est[1], NA,
                             nca_air_pbtk$est[1]/nca_air_ex$est[1], NA)
dataframe$"RMSE"					<- c(RMSE_blood, NA, RMSE_air, NA)
dataframe$"Index"					<- c(Index_blood, NA, Index_air, NA)
dataframe$"Index total"				<- Index_total
dataframe$"t_half"					<- c(thalf_blood_pbtk,
                            thalf_blood_ex,
                            thalf_air_pbtk,
                            thalf_air_ex)
dataframe$"t_halfRatio"				<- c(thalf_blood_pbtk/thalf_blood_ex, NA,
                                thalf_air_pbtk/thalf_air_ex, NA)
dataframe$"R2_elimination"			<- c(r2_blood_pbtk,
                                  r2_blood_ex,
                                  r2_air_pbtk,
                                  r2_air_ex)


####### Going out ########################################
knime.out <- dataframe
