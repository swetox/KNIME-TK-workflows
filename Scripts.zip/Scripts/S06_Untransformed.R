#### Adding PC column with typ of PC #######
knime.in$"PC"	<- knime.flow.in[["currentColumnName"]]

knime.out <- knime.in