######################################################
library(reshape2)

######################################################
######### Slecting data from cross validation ########
colnames(knime.in)[(ncol(knime.in)-3):ncol(knime.in)] <- c("PClabel", "Data", "Transformation", "Tissue")

######### Transforming RMSE #########################
for(i in 1:nrow(knime.in)){
  if(knime.in$"Transformation"[i] != "Log"){
    knime.in$"RMSE"[i] = log10(knime.in$"RMSE"[i])
  }
}

######### Slecting data from cross validation ########
rPC			= match("PC", colnames(knime.in)) 
rPClabel		= match("PClabel", colnames(knime.in)) 
rData		= match("Data", colnames(knime.in)) 
rTrans		= match("Transformation", colnames(knime.in)) 
rTissue		= match("Tissue", colnames(knime.in)) 
rGeneration	= match("Generation", colnames(knime.in)) 
rCombo		= match("Combo", colnames(knime.in)) 
rncomp		= match("n_compounds", colnames(knime.in)) 
rndes		= match("n_descriptors", colnames(knime.in)) 
rR2abs		= match("R2abs", colnames(knime.in)) 
rRMSE		= match("RMSE", colnames(knime.in)) 

lALL= c(rPC, rPClabel, rData, rTrans, rTissue, rGeneration, rCombo, rncomp, rndes, rR2abs, rRMSE)
lID = lALL[1:(length(lALL)-2)]
lMES = lALL[(length(lALL)-1):length(lALL)]

########## Going out ###################################
knime.out <- melt(knime.in, id.vars = colnames(knime.in)[lID], measure.vars = colnames(knime.in)[lMES], variable.name = "Parameter", value.name = "Value")
