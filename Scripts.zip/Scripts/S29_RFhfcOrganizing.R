############# Adding indicator #################
# Selection appropriate PC column:
PCid <- gsub("_[A-Z0-9]*", "", knime.flow.in[["PC"]])
PCid <- gsub("Log", "", PCid)

c = grep(PCid, colnames(knime.in))

if(grepl("Log", knime.flow.in[["PC"]]) == TRUE){
  knime.in[,c] <- log10(knime.in[,c])
}

######### Going out #########
knime.out <- knime.in[,c(1,c, (ncol(knime.in)-1):(ncol(knime.in)))]
colnames(knime.out)[1:4] <- c("Compound", "Observed", "Predicted", "Variance")
knime.out$"Origin" <- knime.in$"Compound"
