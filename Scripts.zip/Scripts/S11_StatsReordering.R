### Creating a name column "Subset" were "Log" is removed"

knime.in$"Subset" <- gsub("Log", "", knime.in$"PC")

knime.out <- knime.in
knime.out <- knime.out[order(knime.out$Subset),]