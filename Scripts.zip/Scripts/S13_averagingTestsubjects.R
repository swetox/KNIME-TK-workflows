
########## Going out ##########
knime.out <- data.frame("Compound" = knime.flow.in[["Compound"]])
knime.out$"Chemical name"		<- unique(knime.in$"Chemical name")
knime.out$"Molecular weight"		<- unique(knime.in$"Molecular weight")
knime.out$"Gender" 				<- knime.flow.in[["Gender"]]
knime.out$"Exposure level"		<- knime.flow.in[["Exposure level"]]
knime.out$"Body height"			<- mean(unique(knime.in$"Height"))
knime.out$"Minimum height"		<- min(unique(knime.in$"Height"))
knime.out$"Maximum height"		<- max(unique(knime.in$"Height"))
knime.out$"Body weight"			<- mean(unique(knime.in$"Weight"))
knime.out$"Minimum weight"		<- min(unique(knime.in$"Height"))
knime.out$"Maximum weight"		<- max(unique(knime.in$"Height"))
knime.out$"Ventilation rest" 		<- mean(unique(knime.in$"Ventilation rest"))
knime.out$"Minimum ventilation rest" <- min(unique(knime.in$"Ventilation rest"))
knime.out$"Maximum ventilation rest" <- max(unique(knime.in$"Ventilation rest"))
knime.out$"Ventilation work" 		<- mean(unique(knime.in$"Ventilation work"))
knime.out$"Minimum ventilation work" <- min(unique(knime.in$"Ventilation work"))
knime.out$"Maximum ventilation work" <- max(unique(knime.in$"Ventilation work"))
