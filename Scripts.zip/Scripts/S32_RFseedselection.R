########## selection ########
c = c("MD", "OOB")

knime.out <- subset(knime.in, 
                    Combo == c[1] &
                      Output == c[2]
)

l = match(c("Seed", "RelNodesize", "Trees"), colnames(knime.out))

knime.out <- knime.out[,l] 