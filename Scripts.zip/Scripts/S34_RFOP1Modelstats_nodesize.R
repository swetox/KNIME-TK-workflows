####### Statistical performance #######
training <- subset(knime.in, Origin == "Training Data")
observed = training$Observed
predicted = training$Predicted

# linear fit
fit <- lm(predicted~observed)

n_compounds 	<- nrow(training)
n_descriptors 	<- unique(training$"n_descriptors")
combo 		<- unique(training$"Combo")
output 		<- unique(training$"Output")
r2_abs		<- 1-(sum((predicted-observed)^2)/(sum((observed-mean(observed))^2)))
rmse			<- sqrt(mean((observed-predicted)^2))
r2 			<- summary(fit)$r.squared
r2_adj 		<- summary(fit)$adj.r.squared
rse 			<- summary(fit)$sigma
mean_variance 	<- mean(training$Variance)
spearman 		<- cor(observed, predicted, method = "spearman")
kendall	 	<- cor(observed, predicted, method = "kendall")
pearson	 	<- cor(observed, predicted, method = "pearson")

#### Going out #####
knime.out 				<- data.frame("PC" = knime.flow.in[["PC"]])
knime.out$"Generation"		<- knime.flow.in[["Generation"]]
knime.out$"Combo" 			<- combo
knime.out$"Output"			<- output
knime.out$"n_compounds"		<- n_compounds
knime.out$"n_descriptors" 	<- n_descriptors
knime.out$"R2abs"			<- r2_abs
knime.out$"RMSE"			<- rmse
knime.out$"R2"				<- r2
knime.out$"R2adj"			<- r2_adj
knime.out$"RSE"			<- rse
knime.out$"Variance"		<- mean_variance
knime.out$"Spearman"		<- spearman
knime.out$"Kendall"			<- kendall
knime.out$"Pearson"			<- pearson

knime.out$"Seed" 			<- knime.flow.in[["Seed"]]
knime.out$"nodesize"		<- knime.flow.in[["nodesizeList"]]
knime.out$"RelNodesize"		<- knime.flow.in[["nodesizeList"]]/as.integer(round(sqrt(n_compounds)))
knime.out$"Trees"			<- knime.flow.in[["Tree"]]
knime.out$"Optimized"		<- "Nodesize"