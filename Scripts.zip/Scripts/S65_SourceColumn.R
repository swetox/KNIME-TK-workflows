knime.out <- knime.in
knime.out$"Source" <- "QSPR"