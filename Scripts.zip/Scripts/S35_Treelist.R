############## Optimimum nodesize #############
nr2 		= match(max(knime.in$"R2abs"), knime.in$"R2abs")
nrmse 	= match(min(knime.in$"RMSE"), knime.in$"RMSE")
n = unique(c(nr2, nrmse))

optimum_nodesize = knime.in$"nodesize"[n]
###############################################
treelist <- as.integer(seq(50, 1500, 25))

nodesize 	= optimum_nodesize
if(nodesize < 6){
  nodesize = as.integer(6)
}
childsize = as.integer(nodesize*0.5)

####### going out ########
knime.out <- data.frame(
  "TreeList" 	= treelist,
  "nodesize"	= nodesize,
  "childsize" 	= childsize,
  "OptimumNodesize" = optimum_nodesize
)

