######### Info on BFE filtration #######
#### Going out ######
knime.out 					<- data.frame("PC" = knime.flow.in[["PC"]])
knime.out$"n_descriptors" 		<- knime.flow.in[["n_descriptors"]]
knime.out$"Seed"				<- knime.flow.in[["seed"]]
knime.out$"Variance"			<- knime.flow.in[["variance"]]
knime.out$"Correlation"			<- knime.flow.in[["correlation"]]
knime.out$"BFElimit"			<- knime.flow.in[["Limit"]]