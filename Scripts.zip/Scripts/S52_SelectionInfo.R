############# Model selection info #########
gen = unique(knime.in$"Generation")
if(gen == "LR1"){
  previousOP <- "LROP2"
} else if(gen == "RF3"){
  previousOP <- "RFOP2"
} else {
  previousOP <- "All"
}


knime.out <- data.frame(
  "Tissue" 		= unique(knime.in$"Tissue"),
  "Generation"	= unique(knime.in$"Generation"),
  "PC"			= unique(knime.in$"PC"),
  "PCgeneral"	= paste("PC", unique(knime.in$"Tissue"), sep = ""),
  "Modelfile"	= unique(knime.in$"Modelfile"),
  "Type"		= unique(knime.in$"Type"),
  "Combo"		= unique(knime.in$"Combo"),
  "Data"		= unique(knime.in$"Data"),
  "Transformation"	= unique(knime.in$"Transformation"),
  "previousOP"	= previousOP
)