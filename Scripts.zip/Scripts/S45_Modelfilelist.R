############ Reading model files ############
modelfiles <- c()

# resultsfolder
resultsfolder = knime.flow.in[["resultsfolder"]]

# separator
sepo = knime.flow.in[["sepo"]]

# model folders 
folders 	= list.files(resultsfolder)
m 		= as.vector(grep("[A-Z]{2}[0-9]{1}models", folders))
folders 	= folders[m]

# modelfiles
for(f in 1:length(folders)){
  folder = paste(resultsfolder, folders[f], sep ="")
  generation = gsub("models","", folders[f])
  type = gsub("[0-9]{1}", "", generation)
  m.files <- list.files(folder)
  m.list = c()
  
  combo.list = c()
  pc.list = c()
  tissue.list = c()
  data.list = c()
  pcgeneral.list = c()
  
  for(m in 1:length(m.files)){
    m.path = paste(folder, sepo, m.files[m], sep ="")
    m.list[m] <- m.path 
    
    data <- strsplit(as.character(m.files[m]), "_")[[1]][3]
    tissue <- gsub("LogPC","", strsplit(as.character(m.files[m]), "_")[[1]][2])
    tissue <- gsub("PC", "", tissue)
    
    combo.list[m] <- unlist(strsplit(strsplit(as.character(m.files[m]), "_")[[1]][4], "[.]"))
    pc.list[m] <- paste(strsplit(as.character(m.files[m]), "_")[[1]][2], "_",data, sep ="")
    tissue.list[m] <- tissue
    data.list[m] <- data
    pcgeneral.list[m] <- paste("PC", tissue, sep = "")
  }
  if(f == 1){
    f1 = data.frame(m.list, pc.list, pcgeneral.list, generation, type, combo.list, tissue.list, data.list)
  } else {
    f2 = data.frame(m.list, pc.list,pcgeneral.list, generation, type, combo.list, tissue.list, data.list)
    f1 = rbind(f1,f2)
  }
}

colnames(f1) <- c("Modelfile","PC", "PCgeneral", "Generation", "Type", "Combo", "Tissue", "Data")

############### Adding information of optimization sheet ######
previousOP <- c()

for(g in 1:nrow(f1)){
  gen = f1$"Generation"[g]
  if(gen == "LR1"){
    previousOP[g] <- "LROP2"
  } else if(gen == "RF3"){
    previousOP[g] <- "RFOP2"
  } else {
    previousOP[g] <- "All"
  }
}

f1$"previousOP" <- previousOP


################ Going out ###################################
knime.out <- f1
