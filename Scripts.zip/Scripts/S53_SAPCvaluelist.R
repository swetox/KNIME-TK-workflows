################ creating list of +-10% PC value #############

PC <- knime.flow.in[["currentColumnName"]]
nc <- match(PC, colnames(knime.in))
PCvalue <- knime.in[,nc]

PClist <- seq(0.9*PCvalue, 1.1*PCvalue,0.01*PCvalue)
PCfold <- PClist/PCvalue

############### Going out ####################################
knime.out <- data.frame(PClist, PCfold)