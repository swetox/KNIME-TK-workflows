# Creating list of corrected names for P1
if(Sys.info()[["sysname"]] == "Darwin"){
  n=4
} else {
  n = 1
}

corrected <-c()

# Were not picked up by Babel-replacement:
corrected[1] <- "1,2,4-trichloro-5-(2,4,5-trichlorophenyl)benzene"
corrected[2] <- "1,3-dichloro-5-(3,5-dichlorophenyl)benzene"
corrected[3] <- "1-chloro-4-(4-chlorophenyl)benzene"

#Corrections:
corrected[4] <- "Amitriptyline"
corrected[5] <- "Dichlorodiphenyl sulfone"
corrected[6] <- "2-Amino-2-[2-(4-octylphenyl)ethyl]-1,3-propanediol"
corrected[7] <- "5,5-Diethyl-1-hexyl-2,4,6(1H,3H,5H)-pyrimidinetrione"
corrected[8] <- "5,5-Diethyl-1-nonyl-2,4,6(1H,3H,5H)-pyrimidinetrione"
corrected[9] <- "1,1'-Sulfonylbis(4-chlorobenzene)"

corrected[10] <- "1,2,4-Trichloro-5-(2,4-dichlorophenoxy)benzene"

corrected[11] <- "2,2',5,5'-Tetrachlorobiphenyl"
corrected[12] <- "2,2',3,3',4,4',5-Heptachlorobiphenyl"  
corrected[13] <- "2,2',3,4,4',5'-Hexachlorobiphenyl"
corrected[14] <- "2,2',3,4,4',5,5'-Heptachlorobiphenyl"
corrected[15] <- "2,2',3,4,5'-Pentachlorobiphenyl"      
corrected[16] <- "1,2,4-trichloro-5-(2,4,5-trichlorophenyl)benzene"
corrected[17] <- "2,2',4,4',5'-Pentachlorobiphenyl"
corrected[18] <- "2,2',4,5,5'-Pentachlorobiphenyl"
corrected[19] <- "2,3,3',4,4'-Pentachlorobiphenyl"
corrected[20] <- "1,2,3,4-tetrachloro-5-(3,4-dichlorophenyl)benzene"   
corrected[21] <- "2,3,3',4,4',5'-Hexachlorobiphenyl"
corrected[22] <- "2,3',4,4',5-Pentachlorobiphenyl"
corrected[23] <- "2,4,4'-Trichlorobiphenyl"
corrected[24] <- "1,2-dichloro-4-(3,4-dichlorophenyl)benzene"

corrected[25] <- "Sufentanil"
corrected[26] <- "Chlorambucil-t-butyl ester"

knime.in$"Corrected" <- corrected[n:26]
knime.out <- knime.in