######################
time <- unique(knime.in$"time")
comp<- unique(knime.in$"Compartment")
r = 0

for(comp in comp){
  r = r+1
  min = c()
  max = c()
  for(i in 1:length(time)){
    t = time[i]
    d <- subset(knime.in, time == t & Compartment == comp)
    min[i] = min(d$Concentration)
    max[i] = max(d$Concentration)
  }  
  if(r == 1){
    d1 <- data.frame(time, "Minimum" = min, "Maximum" = max, "Compartment" = comp)
  } else{
    d2 <- data.frame(time, "Minimum" = min, "Maximum" = max, "Compartment" = comp)
    d1 <- rbind(d1, d2)
  }
}

knime.out <- d1