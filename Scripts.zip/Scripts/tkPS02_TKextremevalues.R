###############################
########## Libraries ###########
library(ggplot2)

mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.8 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.8, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black"),
  axis.title.x =      	element_text(size = base_size, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.15, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.25),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.8),
  legend.title =      element_text(size = base_size * 0.8, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = NA, size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = NA, colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size * 1.2, face = "bold", vjust  = 0.5, hjust = 0.5),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines"),
  plot.subtitle =	element_text(size = base_size * 0.9, face = "bold", vjust  = 0.5, hjust = 0.5)
)
####################################################
################ labels ##############

xlab = "Time (days)"
ylab = "Concentration (\u03BCM)"
scenario =  paste(unique(knime.flow.in$"Compound (IUPAC)"),", ", knime.flow.in[["Exposure level"]], " ppm, ", "Clearance: ", knime.flow.in[["Clearance"]], sep ="")
person = paste((knime.flow.in[["Body height"]]*100), " cm, ", knime.flow.in[["Body weight"]], " kg", sep ="")
title = scenario
subtitle = paste("Person: ", person, sep ="")

max = 10
simlength = knime.flow.in[["SimulationLength"]]
#######################################################
ggplot(knime.in) + mytheme +
  labs(x = xlab, y = ylab, title = title, subtitle = subtitle) + 
  scale_y_log10(expand = c(0,0), limits = c(0.01,100),
                breaks = scales::trans_breaks("log10", function(x) 10^x),
                labels = scales::trans_format("log10", scales::math_format(10^.x))
  ) +
  scale_x_continuous(expand = c(0,0), limits = c(0, simlength), breaks = seq(0,simlength,1))+ 
  theme(
    legend.title = element_blank(),
    legend.position = c(0.85,0.8)) + 
  annotation_logticks(sides = "l", base = 10, color = "black", short = unit(0.2, "cm"), mid= unit(0.2, "cm")) +
  annotate("text", x = 0.5*simlength, y = 1, label = "One of more \n extreme predictions (<0 or >50000), \n No PBTK \n simulation possible", size = base_size*0.8, color = "red", fontface = "bold")

