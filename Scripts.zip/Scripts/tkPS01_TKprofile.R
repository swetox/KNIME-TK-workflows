###############################
########## Libraries ###########
library(ggplot2)

mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.8 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.8, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black"),
  axis.title.x =      	element_text(size = base_size, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.15, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.25),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.8),
  legend.title =      element_text(size = base_size * 0.8, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = NA, size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = NA, colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size * 1.2, face = "bold", vjust  = 0.5, hjust = 0.5),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines"),
  plot.subtitle =        element_text(size = base_size * 0.8, face = "bold", vjust  = 0.5, hjust = 0.5),
)
####################################################
################ labels ##############
data = subset(knime.in, Compartment != "Relupt")
levels(data$"Compartment") <- c(   "Arterial blood", 
                                   "Exhaled air", 
                                   "Fat",
                                   "Liver",
                                   "Lung", 
                                   "Mixed venous blood",
                                   "Resting muscles", 
                                   "Vesselrich group",
                                   "Working muscles", 
                                   "Relative uptake")


xlab_days = "Time (days)"
xlab_hours = "Time (hours)"
ylab = "Concentration (\u03BCM)"
scenario = paste(unique(knime.flow.in$"Compound (IUPAC)"),", ", knime.flow.in[["Exposure level"]], " ppm, ", "Clearance: ", knime.flow.in[["Clearance"]], sep ="")
person = paste((knime.flow.in[["Body height"]]*100), " cm, ", knime.flow.in[["Body weight"]], " kg", sep ="")
title = scenario
subtitle = paste("Person: ", person, sep ="")

max = 10
simlength = knime.flow.in[["SimulationLength"]]

max = max(knime.in$"time")

#######################################################
pDays <- ggplot(data, aes(x = time/(60*24), y = Concentration, color = Compartment)) + mytheme +
  geom_line(cex = 1) +
  labs(x = xlab_days, y = ylab, title = title, subtitle = subtitle) + 
  scale_y_log10(expand = c(0,0),
                breaks = scales::trans_breaks("log10", function(x) 10^x),
                labels = scales::trans_format("log10", scales::math_format(10^.x))
  ) +
  scale_x_continuous(expand = c(0,0), breaks = seq(0,(max/(60*24)),1)) + 
  theme(
    legend.title = element_blank(),
    legend.position = c(0.85,0.8)) + 
  annotation_logticks(sides = "l", base = 10, color = "black", short = unit(0.2, "cm"), mid= unit(0.2, "cm"))

pHours <- ggplot(data, aes(x = time/(60), y = Concentration, color = Compartment)) + mytheme +
  geom_line(cex = 1) +
  labs(x = xlab_hours, y = ylab, title = title, subtitle = subtitle) + 
  scale_y_log10(expand = c(0,0),
                breaks = scales::trans_breaks("log10", function(x) 10^x),
                labels = scales::trans_format("log10", scales::math_format(10^.x))
  ) +
  scale_x_continuous(expand = c(0,0), breaks = seq(0,max/60,2)) + 
  theme(
    legend.title = element_blank(),
    legend.position = c(0.85,0.8)) + 
  annotation_logticks(sides = "l", base = 10, color = "black", short = unit(0.2, "cm"), mid= unit(0.2, "cm"))

if(knime.flow.in[["SimulationLength"]] > 1){
  plot = pDays
} else {
  plot = pHours
}
plot

############# Adding info on Cmax #############################
ymax = ggplot_build(plot)$layout$panel_ranges[[1]]$y.range[[2]]
ymin = ggplot_build(plot)$layout$panel_ranges[[1]]$y.range[[1]]
xmax = ggplot_build(plot)$layout$panel_ranges[[1]]$x.range[[2]]
xmin = ggplot_build(plot)$layout$panel_ranges[[1]]$x.range[[1]]

ythird = (ymax-ymin)/3+ymin
xfourth = xmax - (xmax-xmin)/3

ystep =  (ythird-ymin)/10
xstep = (xmax-xfourth)/12

ypos = seq(ythird, ymin, length.out = 11)[1:10]
cpos = xfourth
signpos = xfourth+6*xstep
cmaxpos = xfourth + 7*xstep
aucpos = xfourth + 10*xstep

comp = as.character(unique(data$Compartment))

# Dataframe with info
info <- data.frame(
  "Compartment" = c("", comp),
  "ypos" = 10^ypos,
  cpos,
  signpos,
  cmaxpos,
  aucpos,
  "Sign" = c("", rep(":", length(comp))),
  "Cmax" = c("bold(Cmax)",  strsplit(knime.flow.in[["Cmax"]], ",")[[1]]),
  "AUC" = c("bold(AUC)", strsplit(knime.flow.in[["AUC"]], ",")[[1]])
)

plot1 <- plot + annotate(
  "rect",
  ymax = 10^(ythird+0.5*ystep),
  ymin = 10^(ymin-0.5*ystep),
  xmax = xmax+0.5*xstep,
  xmin = xfourth-0.5*xstep,
  fill = "white",
  alpha = 0.99)
plot1		
plot2 = plot1

for(n in 1:nrow(info)){
  plot2 <- plot2 + annotate(
    "text",
    y = info$ypos[n],
    x = info$cpos[n],
    hjust = 0,
    label = info$Compartment[n],
    colour = c(NA, scales::hue_pal()(9))[n]) +
    annotate(
      "text",
      y = info$ypos[n],
      x = info$signpos[n],
      hjust = 0,
      label = info$Sign[n],
      colour = c(NA, scales::hue_pal()(9))[n]) +
    annotate(
      "text",
      y = info$ypos[n],
      x = info$cmaxpos[n],
      hjust = 0,
      label = info$Cmax[n],
      parse = TRUE) +
    annotate(
      "text",
      y = info$ypos[n],
      x = info$aucpos[n],
      hjust = 0,
      label = info$AUC[n],
      parse = TRUE) 
}

plot2
