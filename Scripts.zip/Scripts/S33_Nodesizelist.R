##########################
nodesizelist  <- as.integer(seq(2, 50, 1))
childsizelist <- as.integer(nodesizelist/2)
tree			= as.integer(knime.flow.in[["Trees"]])

####### going out ########
knime.out <- data.frame(
  "nodesizeList"= nodesizelist,
  "chilsizeList"= childsizelist,
  "Tree" 		= tree
)

