# Creating list of corrected names for P2

corrected <- c("Cefotetan", "Cefoperazone", "Chlorofluoromethane", "Nicardipine")

knime.in$"Corrected" <- corrected 
knime.out <- knime.in