### Info derived from articles ###

levels <- as.integer(c(500, 500, 0, 200, 1000, 0, 200, 1000, 0, 100, 300, 0, 100, 300))
compound <- c("HFC134a", "HFC143a", "HFC152a", "HFC152a","HFC152a","HFC152a","HFC152a","HFC152a","HFC245fa","HFC245fa", "HFC245fa", "HFC245fa", "HFC245fa", "HFC245fa")
gender 	<- c("Male", "Male", "Male", "Male", "Male", "Female", "Female", "Female", "Male", "Male", "Male", "Female", "Female", "Female")
exposure_avg <- c(486.0, 455.0, 0.0, 194.9,955.8, 0.0, 205.0, 946.3, 0.0, 98.0,296.0, 0.0, 98.0,296.0)

knime.out <- data.frame(levels, compound, gender, exposure_avg)
colnames(knime.out) <- c("Exposure level", "Compound", "Gender", "Average Exposure")
knime.out$"Clearance" <- 0