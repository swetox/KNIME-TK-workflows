######## Calculating number of descriptors ######
n_compounds 	= nrow(knime.in)
n_descriptors 	= ncol(knime.in)

# Indicator of reduction #
ok 			= ifelse(n_compounds > n_descriptors, "OK", "not OK")

if(knime.flow.in[["correlation"]] == 0.06){
  ok = "OK"
}

####### Generating seed ########
# Random seed:
seed <- as.integer(sample(1:100000,1))

#### Going out ####
knime.out <- data.frame("PC" = knime.flow.in[["PC"]])
knime.out$"n_compounds" 		<- n_compounds
knime.out$"n_descriptors" 	<- n_descriptors
knime.out$"variance" 		<- knime.flow.in[["variance"]]
knime.out$"correlation" 		<- knime.flow.in[["correlation"]]
knime.out$"seed" 			<- seed
knime.out$"Indicator"		<- ok