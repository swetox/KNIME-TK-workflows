####### Transforming ########
compounds <- as.character(knime.in$"Substance")
human <- as.character(knime.in[,2])
rat <- as.character(knime.in[,3])

knime.out <- data.frame("Compound" = compounds)
knime.out$"PCblood_B1" <- 10^(as.numeric(human))
knime.out$"PCblood_B2" <- 10^(as.numeric(rat))

