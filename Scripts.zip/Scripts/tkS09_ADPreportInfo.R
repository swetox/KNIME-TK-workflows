############## Adding info of prediction (and model) ############
knime.out <- knime.in

knime.out$"PC" <- knime.flow.in[["PCgeneral"]]


n = match("Prediction", colnames(knime.out))
colnames(knime.out)[n] <- "Reliability"