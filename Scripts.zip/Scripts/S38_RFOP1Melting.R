########### melting and renaming ##############
library(reshape2)

#### Renaming ########
colnames(knime.in)[(ncol(knime.in)-1):ncol(knime.in)] <- c("PClabel", "Data")

rR2			= match("R2abs", colnames(knime.in))
rRMSE		= match("RMSE", colnames(knime.in))
rTrees		= match("Trees", colnames(knime.in))
rRelNodesize 	= match("RelNodesize", colnames(knime.in))
rPClabel 		= match("PClabel", colnames(knime.in))
rData		= match("Data", colnames(knime.in))
rOptimized	= match("Optimized", colnames(knime.in))

######## melting dataframes ########
d1 = subset(knime.in, Optimized == "Trees")
d1 = d1[,c(rPClabel, rData, rOptimized, rTrees, rR2, rRMSE)]
colnames(d1)[4] <- "ValueOptimized"

d2 = subset(knime.in, Optimized == "Nodesize")
d2 = d2[,c(rPClabel, rData, rOptimized, rRelNodesize, rR2, rRMSE)]
colnames(d2)[4] <- "ValueOptimized"

######## Joining ########
knime.out <- rbind(d1, d2)
knime.out <- melt(knime.out, id.vars = c("PClabel", "Data", "Optimized", "ValueOptimized"), measure.vars = c("R2abs", "RMSE"), variable.name = "Parameter", value.name = "Value") 

