library(PK)
################ Calculation of AUC and Cmax ################
size = 2400

comp = unique(knime.in$Compartment)
auclist = c()
cmaxlist = c()


for(j in 1:length(comp)){
  c = comp[j]
  d = subset(knime.in, Compartment == c)
  time = unique(d$"time")
  pos = seq(1,length(time), size)
  timepoints = time[pos]
  for(i in 1:(length(pos)-1)){
    t1 = timepoints[i]
    t2 = timepoints[i+1]
    dt = subset(d, time >= t1 & time < t2)
    if(i == 1){
      AUC = nca.complete(time = dt$time, conc = dt$Concentration)$est[1]
    } else{
      a = nca.complete(time = dt$time, conc = dt$Concentration)$est[1]
      AUC = AUC+ a
    }
  } 
  auclist[j] = round(AUC)
  cmaxlist[j] = round(max(d$Concentration))
}

############### Going out ################################
knime.out <- data.frame(
  "Comp" = paste(comp, collapse =","),
  "Cmax" = paste(as.character(cmaxlist), collapse = ","),
  "AUC" = paste(as.character(auclist), collapse =",")
)