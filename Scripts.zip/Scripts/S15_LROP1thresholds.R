######### List of thresholds for correlation and variance filter ########
varlist <- seq(0,1,0.01)
corlist <- seq(1,0.06,-0.01)

## Current interation ####
i = knime.flow.in[["currentIteration"]] +1

############ Going out ############
knime.out				<- data.frame("variance" = signif(varlist[i], 2))
knime.out$"correlation" 	<- signif(corlist[i],2)
knime.out$"iteration" 	<- i