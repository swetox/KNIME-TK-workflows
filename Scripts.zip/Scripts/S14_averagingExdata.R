######### Converting concentrations to �M #####

##### Constants ######
R_L <- 8.3144598*10^-2 						# L*bar*K^1*mol^1
T 	<- 273.15+unique(knime.in$"Temperature")	# K
p 	<- 1									# bar

# Molecular weight:
MW =unique(knime.in$"Molecular weight")			# g/mol

# Molecular volume
Vm <- R_L*T/p			# L/mol

#### Converting mg/m3 #######
unit = unique(knime.in$"Concentration unit")

if(unit == "mg/m3"){
  knime.in$"Concentration" <- knime.in$"Concentration"/MW
  knime.in$"Concentration unit" <- paste('\u03BC', "M", sep="")
}

#### Converting ppm #######
#### NOT DONE HERE #######
#if(unit == "ppm"){
#	knime.in$"Concentration" <- knime.in$"Concentration"/Vm
#	knime.in$"Concentration unit" <- paste('\u03BC', "M", sep=""))
#}

### Average for gender and exposure #######
timepoints 		= unique(knime.in$"Time point")
time_avg 			= as.numeric(timepoints)
concentration_avg 	= as.numeric(timepoints)
cmin				= as.numeric(timepoints)
cmax				= as.numeric(timepoints)

for(i in 1:length(timepoints)){
  timepoint <- timepoints[i]
  d <- subset(knime.in, knime.in$"Time point" == timepoint)
  
  t_avg <- mean(d$"Time")
  time_avg[i] <- round(t_avg, 1)
  
  c_avg <- mean(d$"Concentration")
  concentration_avg[i] <- round(c_avg, 3)	
  
  c_min <- min(d$"Concentration")
  cmin[i] <- round(c_min, 3)
  
  c_max <- max(d$"Concentration")
  cmax[i] <- round(c_max, 3)
}

########## Going out ##########
knime.out <- data.frame("time" 	= time_avg)
knime.out$"Concentration" 		<- concentration_avg
knime.out$"Minimum"				<- cmin
knime.out$"Maximum"				<- cmax
knime.out$"Compartment" 			<- knime.flow.in[["Tissue"]]
knime.out$"Compound" 			<- knime.flow.in[["Compound"]]
knime.out$"Chemical name"		<- unique(knime.in$"Chemical name")
knime.out$"Unit"				<- unique(knime.in$"Concentration unit")
knime.out$"Molecular weight"		<- unique(knime.in$"Molecular weight")
knime.out$"Gender" 				<- knime.flow.in[["Gender"]]
knime.out$"Exposure level"		<- knime.flow.in[["Exposure level"]]
knime.out$"Body height"			<- mean(unique(knime.in$"Height"))
knime.out$"Minimum height"		<- min(unique(knime.in$"Height"))
knime.out$"Maximum height"		<- max(unique(knime.in$"Height"))
knime.out$"Body weight"			<- mean(unique(knime.in$"Weight"))
knime.out$"Minimum weight"		<- min(unique(knime.in$"Height"))
knime.out$"Maximum weight"		<- max(unique(knime.in$"Height"))
knime.out$"Ventilation rest" 		<- mean(unique(knime.in$"Ventilation rest"))
knime.out$"Minimum ventilation rest" <- min(unique(knime.in$"Ventilation rest"))
knime.out$"Maximum ventilation rest" <- max(unique(knime.in$"Ventilation rest"))
knime.out$"Ventilation work" 		<- mean(unique(knime.in$"Ventilation work"))
knime.out$"Minimum ventilation work" <- min(unique(knime.in$"Ventilation work"))
knime.out$"Maximum ventilation work" <- max(unique(knime.in$"Ventilation work"))

